#!/bin/bash
#build and deploy script:
buildLable="B2Bv8"
svnURL=https://172.24.161.31/repo/PVH/branches/PVH-B2B-V8
ENV=$1
svnBranch=$2
runExtract=$3
echo $ENV : $svnBranch
cd /opt/IBM/WebSphere/CommerceServer80/wcbd
if [ "$svnBranch" == "trunk" ]
	then
		rm build.properties
		cp build.properties-updatesvn build.properties
		svnURL=https://172.24.161.31/repo/PVH/branches/PVH-B2B-V8
		buildLable="B2Bv8"
	else
		rm build.properties
		cp build.properties-checkoutsvn build.properties
#		svnURL=https://192.168.110.2/repos/THCKUS/tags/$svnBranch
		svnURL=https://172.24.161.31/repo/PVH/tags/$svnBranch
		buildLable="B2Bv8-$svnBranch"
fi
echo "SVN URL: $svnURL"
echo "buildLable: $buildLable"
echo "runExtract: $runExtract"
#build command
./wcbd-ant -buildfile wcbd-build.xml -Dbuild.label=$buildLable -Dsvn.url=$svnURL -Drun.extract=$runExtract


