#!/bin/bash
# Search single file deploy using wsadmin

WAS_HOME="/opt/IBM/WebSphere/AppServer"

ENV=$1
insanceName=""
hostName=""
propFile=""
serverDir="/opt/IBM/WebSphere/CommerceServer80/wcbd/deploy/server"
propFile="$serverDir/deploy-$ENV.properties"

if [ \( "$ENV" = "stage" \) -o \( "$ENV" = "prod-cell1"  \) -o \( "$ENV" = "prod-cell2"  \) ]; then
	
	if [ -f "$propFile" ]; then
		
		insanceName=`cat $propFile | grep "wc.instance.name=" | cut -d'=' -f2`
		hostName=`cat $propFile | grep "was.host.list" | cut -d'=' -f2`
		
	else
        	echo "$propFile not found."
        	exit
	fi
else
        echo "usage: $0 ENV"
        echo "ENV: stage, prod-cell1 or prod-cell2."
        exit
fi

sourceDir="/opt/IBM/WebSphere/CommerceServer80/wcbd/dist/server/wcbd-deploy-server-B2Bv8/source"
URI="wc.ear/xml/config/com.ibm.commerce.catalog/wc-search.xml"
command="\"AdminApp.update('"$insanceName"', 'file', '[-operation addupdate -contents "$sourceDir/$URI" -contenturi "$URI"]')\""

$WAS_HOME/bin/wsadmin.sh -conntype SOAP -host $hostName -port 8879 -lang jython -c "$command"
$WAS_HOME/bin/wsadmin.sh -conntype SOAP -host $hostName -port 8879 -lang jython -c "AdminConfig.save()"
