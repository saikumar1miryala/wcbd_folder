#-----------------------------------------------------------------
# Licensed Materials - Property of IBM
#
# WebSphere Commerce
#
# (C) Copyright IBM Corp. 2010 All Rights Reserved.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.
#-----------------------------------------------------------------

#-------------------------------------------------------------------------------
# Set up command-line arguments
#-------------------------------------------------------------------------------
# The application name.
aAppName = sys.argv[0]

# The wsadmin script directory
aScriptDir = sys.argv[1]

#-------------------------------------------------------------------------------
# Import wcbd-wsadmin-common.py to get access to helper methods
#-------------------------------------------------------------------------------
execfile(aScriptDir + "/wcbd-wsadmin-common.py")

#-------------------------------------------------------------------------------
# List applications and verify that the WC application is in the list
#-------------------------------------------------------------------------------
appList = wsadminToList(AdminApp.list())
wcAppExist = 0
for app in appList:
    if (app == aAppName):
        wcAppExist = 1
    #endIf
#endFor
if (not wcAppExist):
    print("ERROR: The application application " + aAppName
            + " is not found on the server.")
    sys.exit(1)
#endIf
