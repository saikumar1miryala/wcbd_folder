#-----------------------------------------------------------------
# Licensed Materials - Property of IBM
#
# WebSphere Commerce
#
# (C) Copyright IBM Corp. 2007, 2013 All Rights Reserved.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.
#-----------------------------------------------------------------

from time import strftime
from time import sleep
import sys

#-------------------------------------------------------------------------------
# Set up command-line arguments
#-------------------------------------------------------------------------------
# The application name.
aAppName = sys.argv[0]

# The wsadmin script directory
aScriptDir = sys.argv[1]

# The directory containing Java EE module assets to be deployed
aModuleDir = sys.argv[2]

# The comma-separated list of connector modules to be deployed
aConnectorModuleList = sys.argv[3]

# The comma-separated list of EJB modules to be deployed
aEjbModuleList = sys.argv[4]

# The datasource JNDI name used by EJB modules
aDataSourceJNDIName = sys.argv[5]

# The comma-separated list of Web modules to be deployed
aWebModuleList = sys.argv[6]

# The comma-separated Web module-context root mapping list
aContextRootMappingList = sys.argv[7]

# The path to the partial application zip file.
aPartialAppZipFile = sys.argv[8]

# Boolean value of whether rollout update is executed
aRolloutUpdate = sys.argv[9]

# Timeout value for rollout update
aTimeout = sys.argv[10]

# The comma-separated Web module-virtual host mapping list
aVirtualHostMappingList = sys.argv[11]

# Whether the partial application update should be performed as a full update
aPartialAppFullUpdate = sys.argv[12]

# The CSV file that contains mapping options
aMappingOptionFile = sys.argv[13]

# The comma-separated list of connector modules to be deleted
aConnectorModuleDeleteList = sys.argv[14]

# The comma-separated list of EJB modules to be deleted
aEjbModuleDeleteList = sys.argv[15]

# The comma-separated list of Web modules to be deleted
aWebModuleDeleteList = sys.argv[16]

# Whether the Web server plug-in configuration should be regenerated at the end
# of the application update
aRegenPluginCfg = sys.argv[17]

# Whether the application update process should wait until the WebSphere
# Commerce application is propagated and started on all nodes in a cluster
aWaitAppReady = sys.argv[18]

# The comma-separated list of connector module JNDI names
aConnectorModuleJndiList = sys.argv[19]

#-------------------------------------------------------------------------------
# Import wcbd-wsadmin-common.py to get access to helper methods
#-------------------------------------------------------------------------------
execfile(aScriptDir + "/wcbd-wsadmin-common.py")

#-------------------------------------------------------------------------------
# Load mapping options file and set up dictionary for token replacement
#-------------------------------------------------------------------------------
if (aMappingOptionFile.strip() == ""):
    mappingOptionList = []
#endIf
else:
    mappingOptionList = parseCSVFile(aMappingOptionFile)
    print("Validating mapping options in " + aMappingOptionFile + ".")
    if (not validateMappingOptions(mappingOptionList)):
        sys.exit("Mapping option validation FAILED.")
    #endIf
#endIf

tokenDict = { "@WC_DATA_SOURCE_JNDI_NAME@": aDataSourceJNDIName }

#-------------------------------------------------------------------------------
# Add/update connector modules
#-------------------------------------------------------------------------------
if (aConnectorModuleList.strip() == ""):
    connectorModuleList = []
#endIf
else:
    connectorModuleList = aConnectorModuleList.split(",")
#endElse
if (aConnectorModuleJndiList.strip() == ""):
    connectorModuleJndiList = []
#endIf
else:
    connectorModuleJndiList = aConnectorModuleJndiList.split(",")
#endElse
for connectorModule in connectorModuleList:
    connectorModule = connectorModule.strip()
    moduleURI = connectorModule + ".rar"
    print("Deploying connector module " + moduleURI + " to " + aAppName + ".")
    print("Started: " + strftime("%Y/%m/%d %H:%M:%S"))
    addOrUpdateConnectorModule(aAppName, aModuleDir + "/" + moduleURI,
            moduleURI, connectorModule)
    for connectorJndi in connectorModuleJndiList:
        mappingPair = connectorJndi.split(":")
        if (mappingPair[0].strip() == moduleURI):
            jndiName = mappingPair[1].strip()
            createOrUpdateAndMapJ2CCF(aAppName, moduleURI, "true", jndiName, moduleURI)
        #endIf
    #endFor
    print("Ended: " + strftime("%Y/%m/%d %H:%M:%S"))
#endFor

#-------------------------------------------------------------------------------
# Add/update Web modules
#-------------------------------------------------------------------------------
if (aWebModuleList.strip() == ""):
    webModuleList = []
#endIf
else:
    webModuleList = aWebModuleList.split(",")
#endElse
if (aContextRootMappingList.strip() == ""):
    contextRootMappingList = []
#endIf
else:
    contextRootMappingList = aContextRootMappingList.split(",")
#endElse
if (aVirtualHostMappingList.strip() == ""):
    virtualHostMappingList = []
#endIf
else:
    virtualHostMappingList = aVirtualHostMappingList.split(",")
#endElse
for webModule in webModuleList:
    webModule = webModule.strip()
    moduleURI = webModule + ".war"
    contextRoot = ""
    for contextRootMapping in contextRootMappingList:
        mappingPair = contextRootMapping.split(":")
        if (mappingPair[0].strip() == moduleURI):
            contextRoot = mappingPair[1].strip()
        #endIf
    #endFor
    virtualHost = ""
    for virtualHostMapping in virtualHostMappingList:
        mappingPair = virtualHostMapping.split(":")
        if (mappingPair[0].strip() == moduleURI):
            virtualHost = mappingPair[1].strip()
        #endIf
    #endFor
    print("Deploying Web module " + moduleURI + " to " + aAppName + ".")
    print("Started: " + strftime("%Y/%m/%d %H:%M:%S"))
    addOrUpdateWebModule(aAppName, aModuleDir + "/" + moduleURI, moduleURI,
            contextRoot, virtualHost, webModule)
    print("Ended: " + strftime("%Y/%m/%d %H:%M:%S"))
#endFor

#-------------------------------------------------------------------------------
# Add/update EJB modules
#-------------------------------------------------------------------------------
if (aEjbModuleList.strip() == ""):
    ejbModuleList = []
#endIf
else:
    ejbModuleList = aEjbModuleList.split(",")
#endElse
for ejbModule in ejbModuleList:
    ejbModule = ejbModule.strip()
    moduleURI = ejbModule + ".jar"
    print("Deploying EJB module " + moduleURI + " to " + aAppName + ".")
    print("Started: " + strftime("%Y/%m/%d %H:%M:%S"))
    addOrUpdateEJBModule(aAppName, aModuleDir + "/" + moduleURI, moduleURI,
            aDataSourceJNDIName, ejbModule, mappingOptionList, tokenDict)
    print("Ended: " + strftime("%Y/%m/%d %H:%M:%S"))
#endFor

#-------------------------------------------------------------------------------
# Update with partial application zip file
#-------------------------------------------------------------------------------
print("Deploying " + aPartialAppZipFile + " to " + aAppName + ".")
print("Started: " + strftime("%Y/%m/%d %H:%M:%S"))
updateWithPartialApp(aAppName, aPartialAppZipFile, aPartialAppFullUpdate)
print("Ended: " + strftime("%Y/%m/%d %H:%M:%S"))

#-------------------------------------------------------------------------------
# Delete connector modules
#-------------------------------------------------------------------------------
if (aConnectorModuleDeleteList.strip() == ""):
    connectorModuleDeleteList = []
#endIf
else:
    connectorModuleDeleteList = aConnectorModuleDeleteList.split(",")
#endElse
for connectorModule in connectorModuleDeleteList:
    connectorModule = connectorModule.strip()
    moduleURI = connectorModule + ".rar"
    print("Deleting connector module " + moduleURI + " from " + aAppName + ".")
    print("Started: " + strftime("%Y/%m/%d %H:%M:%S"))
    deleteModule(aAppName, moduleURI)
    print("Ended: " + strftime("%Y/%m/%d %H:%M:%S"))
#endFor

#-------------------------------------------------------------------------------
# Delete Web modules
#-------------------------------------------------------------------------------
if (aWebModuleDeleteList.strip() == ""):
    webModuleDeleteList = []
#endIf
else:
    webModuleDeleteList = aWebModuleDeleteList.split(",")
#endElse
for webModule in webModuleDeleteList:
    webModule = webModule.strip()
    moduleURI = webModule + ".war"
    print("Deleting Web module " + moduleURI + " from " + aAppName + ".")
    print("Started: " + strftime("%Y/%m/%d %H:%M:%S"))
    deleteModule(aAppName, moduleURI)
    print("Ended: " + strftime("%Y/%m/%d %H:%M:%S"))
#endFor

#-------------------------------------------------------------------------------
# Delete EJB modules
#-------------------------------------------------------------------------------
if (aEjbModuleDeleteList.strip() == ""):
    ejbModuleDeleteList = []
#endIf
else:
    ejbModuleDeleteList = aEjbModuleDeleteList.split(",")
#endElse
for ejbModule in ejbModuleDeleteList:
    ejbModule = ejbModule.strip()
    moduleURI = ejbModule + ".jar"
    print("Deleting EJB module " + moduleURI + " from " + aAppName + ".")
    print("Started: " + strftime("%Y/%m/%d %H:%M:%S"))
    deleteModule(aAppName, moduleURI)
    print("Ended: " + strftime("%Y/%m/%d %H:%M:%S"))
#endFor

#-------------------------------------------------------------------------------
# Save configuration
#-------------------------------------------------------------------------------
print("Saving configuration.")
print("Started: " + strftime("%Y/%m/%d %H:%M:%S"))
save(aRolloutUpdate, aAppName, aTimeout)
print("Ended: " + strftime("%Y/%m/%d %H:%M:%S"))

#-------------------------------------------------------------------------------
# Wait for the application to be ready
#-------------------------------------------------------------------------------
if (aWaitAppReady == "true"):
    print("Waiting for application to be ready.")
    print("Started: " + strftime("%Y/%m/%d %H:%M:%S"))
    while (AdminApp.isAppReady(aAppName) == "false"):
        sleep(60)
    #endWhile
    print("Ended: " + strftime("%Y/%m/%d %H:%M:%S"))
#endIf

#-------------------------------------------------------------------------------
# Regenerate plug-in configuration
#-------------------------------------------------------------------------------
if (aRegenPluginCfg == "true"):
    print("Regenerating plug-in configuration.")
    print("Started: " + strftime("%Y/%m/%d %H:%M:%S"))
    regenPluginCfg(aAppName, "false")
    print("Ended: " + strftime("%Y/%m/%d %H:%M:%S"))
#endIf
