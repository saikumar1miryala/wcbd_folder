BRANCH_NAME=$1
TAG=$2

read -p "SVN USERNAME : " SVN_USER
read -p "SVN PASSWORD : " SVN_PWD

rm -rf /opt/IBM/WebSphere/CommerceServer80/wcbd/logs/*
rm -rf /opt/IBM/WebSphere/CommerceServer80/wcbd/dist/server/*.zip

branchExists=$(svn ls https://216.32.220.8/repos/THCKUS/tags/${TAG} --trust-server-cert --non-interactive  --username ${SVN_USER} --password ${SVN_PWD})

if [ ! -z "$branchExists" ]; then
	printf "TAG https://216.32.220.8/repos/THCKUS/tags/${TAG} ALREADY EXISTS. WILL USE EXISTING TAG \n"
else
	svn cp https://216.32.220.8/repos/THCKUS/branches/${BRANCH_NAME} https://216.32.220.8/repos/THCKUS/tags/${TAG} -m dev_build  --username ${SVN_USER} --password ${SVN_PWD} --trust-server-cert --non-interactive

fi

rm -rf /opt/IBM/WebSphere/CommerceServer80/wcbd/source/build/workspace/Stores/src/pvh.targetable.*

svn revert /opt/IBM/WebSphere/CommerceServer80/wcbd/source/build -R

svn switch https://216.32.220.8/repos/THCKUS/tags/${TAG}/workspace /opt/IBM/WebSphere/CommerceServer80/wcbd/source/build/workspace --username ${SVN_USER} --password ${SVN_PWD} --trust-server-cert --non-interactive

#./wcbd-ant -buildfile pvh-build.xml -v -Dbuild.label=${TAG} -Dbuild.type=wc

#./wcbd-ant -buildfile pvh-build.xml -v -Dbuild.label=${TAG} -Dbuild.type=search


